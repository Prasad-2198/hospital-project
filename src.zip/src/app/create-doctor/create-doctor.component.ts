import { Component, OnInit } from '@angular/core';
import { Doctor } from '../doctor';
import { DoctorService } from '../doctor.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-doctor',
  templateUrl: './create-doctor.component.html',
  styleUrls: ['./create-doctor.component.css']
})
export class CreateDoctorComponent implements OnInit {
  doctor: Doctor = new Doctor();
  doctorForm!: FormGroup;

  constructor(
    protected doctorService: DoctorService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    // Initialize the form here instead of throwing an error
    this.initForm();
  }

  initForm() {
    this.doctorForm = this.formBuilder.group({
      doctorfirstname: ['', Validators.required],
      doctorlastname: ['', Validators.required],
      doctoremail: ['', [Validators.required, Validators.email]],
      doctormobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      doctorpassword: ['', Validators.required]
    });
  }

  saveDoctor() {
    this.doctorService.createDoctor(this.doctor).subscribe(
      (data) => {
        console.log(data);
      },
      (error: any) => console.log(error)
    );
    this.goToDoctorList();
  }

  goToDoctorList() {
    this.router.navigate(['/Home/Doctor']);
  }

  onSubmit() {
    if (this.doctorForm.valid) {
      // Use form values instead of ngModel values
      this.doctor.doctorfirstname = this.doctorForm.value.doctorfirstname;
      this.doctor.doctorlastname = this.doctorForm.value.doctorlastname;
      this.doctor.doctoremail = this.doctorForm.value.doctoremail;
      this.doctor.doctormobile = this.doctorForm.value.doctormobile;
      this.doctor.doctorpassword = this.doctorForm.value.doctorpassword;
  
      this.saveDoctor();
    } else {
      console.log('Form is invalid.');
    }
  }
}





















// import { Component, OnInit } from '@angular/core';
// import { Doctor } from '../doctor';
// import { DoctorService } from '../doctor.service';
// import { Router } from '@angular/router';
// import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

// @Component({
//   selector: 'app-create-doctor',
//   templateUrl: './create-doctor.component.html',
//   styleUrls: ['./create-doctor.component.css']
// })
// export class CreateDoctorComponent implements OnInit {
//    doctor:Doctor=new Doctor();
//    doctorForm!: FormGroup;
  
//    constructor(protected doctorService:DoctorService,private router:Router,private formBuilder: FormBuilder){}
  
//   ngOnInit(): void {
//     throw new Error('Method not implemented.');
//     this.initForm();
//   }
//   initForm() {
//     this.doctorForm = this.formBuilder.group({
//       doctorfirstname: ['', Validators.required],
//       doctorlastname: ['', Validators.required],
//       doctoremail: ['', [Validators.required, Validators.email]],
//       doctormobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
//       doctorpassword: ['', Validators.required]
//     });
//   }
  
//   saveDoctor(){
//     this.doctorService.createDoctor(this.doctor).subscribe(data =>{
//       console.log(data);
//     },
//     (error:any)=>console.log(error));
//     this.goToDoctorList();
  
//   }

//   goToDoctorList()
//   {
//     this.router.navigate(['/Home/Doctor']);
//   }



//   onSubmit(){

//       console.log(this.doctor);
//       this.saveDoctor();


//       if (this.doctorForm.valid) {
//         // Submit the form data or perform further actions
//         console.log(this.doctorForm.value);
//       } else {
//         // Display an error message or handle invalid form
//         console.log('Form is invalid.');
//       }
    
//   }








// }
