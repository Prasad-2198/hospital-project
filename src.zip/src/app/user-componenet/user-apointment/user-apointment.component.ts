import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-apointment',
  templateUrl: './user-apointment.component.html',
  styleUrls: ['./user-apointment.component.css']
})
export class UserApointmentComponent {
  firstname: string ="";
  lastname: string ="";
  appointmentdate!: string;
  doctorname:string="";
  disease: string ="";
 appointment1: any;

 constructor(private http: HttpClient ,private router: Router)
  {

  }




  onSubmit(){

    if (!this.isFutureAppointment()) {
      alert("Please select a date and time starting from the current date and time.");
      return;
    }

    else{
    let bodyData = {
      "firstname":this.firstname,
      "lastname":this.lastname,
      "appointmentdate":this. appointmentdate,
      "doctorname":this.doctorname,
      "disease":this.disease
    };
    this.http.post("http://localhost:8084/api/v1/appointment/save",bodyData,{responseType: 'text'}).subscribe((resultData: any)=>
    {
        console.log(resultData);
        alert("Appointment booked Successfully");

        this.router.navigateByUrl('user-Home');

    });
  }

  }
  isFutureAppointment(): boolean {
    if (!this.appointmentdate) {
      return false;
    }

    const selectedDate = new Date(this.appointmentdate).getTime();
    const currentDate = new Date().getTime();

    return selectedDate >= currentDate;
  }


}
