import { Nurse } from './nurse';

describe('Nurse', () => {
  it('should create an instance', () => {
    expect(new Nurse()).toBeTruthy();
  });
});
