import { Component, OnInit } from '@angular/core';
import { Nurse } from '../nurse';
import { NurseService } from '../nurse.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-nurse',
  templateUrl: './create-nurse.component.html',
  styleUrls: ['./create-nurse.component.css']
})
export class CreateNurseComponent  implements OnInit {
  nurse: Nurse = new Nurse();
  nurseForm!: FormGroup;

  constructor(
    protected nurseService: NurseService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    // Initialize the form here instead of throwing an error
    this.initForm();
  }

  initForm() {
    this.nurseForm = this.formBuilder.group({
      nursefirstname: ['', Validators.required],
      nurselastname: ['', Validators.required],
      nurseemail: ['', [Validators.required, Validators.email]],
      nursemobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      nursepassword: ['', Validators.required]
    });
  }

  saveNurse() {
    this.nurseService.createNurse(this.nurse).subscribe(
      (data) => {
        console.log(data);
      },
      (error: any) => console.log(error)
    );
    this.goToNurseList();
  }

  goToNurseList() {
    this.router.navigate(['/Home/Nurse']);
  }

  onSubmit() {
    if (this.nurseForm.valid) {
      // Use form values instead of ngModel values
      this.nurse.nursefirstname = this.nurseForm.value.nursefirstname;
      this.nurse.nurselastname = this.nurseForm.value.nurselastname;
      this.nurse.nurseemail = this.nurseForm.value.nurseemail;
      this.nurse.nursemobile = this.nurseForm.value.nursemobile;
      this.nurse.nursepassword = this.nurseForm.value.nursepassword;
  
      this.saveNurse();
    } else {
      console.log('Form is invalid.');
    }
  }
}