export class Doctor {

    doctorid!:number;
    doctorfirstname!:string;
    doctorlastname!:string;
    doctoremail!:string;
    doctormobile!:number;
    doctorpassword!:String;
}
